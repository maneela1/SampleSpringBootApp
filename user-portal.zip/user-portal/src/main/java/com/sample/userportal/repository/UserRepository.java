package com.sample.userportal.repository;

import org.springframework.data.repository.CrudRepository;

import com.sample.userportal.domain.User;

public interface UserRepository extends CrudRepository<User, Long> {

    /*void delete(User user);

    List<User> findAll();

    User findById(Long id);

    User save(User user);*/
}
