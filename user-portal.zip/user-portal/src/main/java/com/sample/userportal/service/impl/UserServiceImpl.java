package com.sample.userportal.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.userportal.domain.User;
import com.sample.userportal.repository.UserRepository;
import com.sample.userportal.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository repository;

    @Override
    public User create(User user) {
        return repository.save(user);
    }

    @Override
    public User delete(Long id) {
        User user = findById(id);
            repository.delete(user);
        return user;
    }

    @Override
    public List<User> findAll() {
        return (List<User>) repository.findAll();
    }

    @Override
    public User findById(Long id) {
    	User user = null;
    	Optional<User> userOptional = repository.findById(id);
    	
    	if(userOptional.isPresent()){
    		user = userOptional.get();
    	}
    	
        return user;
    }

    @Override
    public User update(User user) {
        return repository.save(user);
    }
}
